
import admin.LoginGUI;

public class Login {
    public static void main(String[] args){
        LoginGUI login = new LoginGUI();
        login.setup();
    }
}


